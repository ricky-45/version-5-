package group.example.KanbanHiringPortal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KanbanHiringPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(KanbanHiringPortalApplication.class, args);
	}

}
