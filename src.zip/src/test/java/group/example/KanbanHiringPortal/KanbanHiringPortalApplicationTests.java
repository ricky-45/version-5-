package group.example.KanbanHiringPortal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KanbanHiringPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
